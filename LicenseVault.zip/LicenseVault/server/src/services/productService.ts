import fs from "node:fs";
import path from "node:path";
import { v4 as uuid } from "uuid";
import { config } from "../config.js";
import { productRepo, productVersionRepo } from "../db/db.js";
import { sha256Hex } from "../utils/crypto.js";
import { ApiError } from "../middleware/errorHandler.js";

fs.mkdirSync(config.productStorageDir, { recursive: true });

export function createProduct(name: string, description: string) {
  const id = uuid();
  productRepo.create({ id, name, description });
  return productRepo.findById(id)!;
}

export function listProducts() {
  return productRepo.list();
}

export function getProductOrThrow(id: string) {
  const product = productRepo.findById(id);
  if (!product) throw new ApiError(404, "Product not found.");
  return product;
}

export function updateProduct(id: string, fields: Partial<{ name: string; description: string; enabled: boolean }>) {
  getProductOrThrow(id);
  const updated = productRepo.update(id, fields as never);
  if (!updated) throw new ApiError(404, "Product not found.");
  return updated;
}

export function deleteProduct(id: string) {
  const product = getProductOrThrow(id);
  const versions = productVersionRepo.listForProduct(id);
  for (const v of versions) {
    safeUnlink(v.storage_path);
  }
  productRepo.delete(product.id);
}

export function addProductVersion(
  productId: string,
  version: string,
  originalFilename: string,
  fileBuffer: Buffer
) {
  getProductOrThrow(productId);

  const safeVersion = version.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 64);
  const id = uuid();
  const destDir = path.join(config.productStorageDir, productId);
  fs.mkdirSync(destDir, { recursive: true });
  const storedFilename = `${safeVersion}-${id}${path.extname(originalFilename).slice(0, 20)}`;
  const storagePath = path.join(destDir, storedFilename);

  fs.writeFileSync(storagePath, fileBuffer);

  productVersionRepo.create({
    id,
    product_id: productId,
    version,
    filename: originalFilename,
    storage_path: storagePath,
    sha256: sha256Hex(fileBuffer),
    size_bytes: fileBuffer.length,
    is_latest: 1,
  });

  return productVersionRepo.findById(id)!;
}

export function listVersions(productId: string) {
  getProductOrThrow(productId);
  return productVersionRepo.listForProduct(productId);
}

export function latestVersionOrThrow(productId: string) {
  const version = productVersionRepo.latestForProduct(productId);
  if (!version) throw new ApiError(404, "This product has no published version yet.");
  return version;
}

function safeUnlink(p: string) {
  try {
    fs.unlinkSync(p);
  } catch {
    // file may already be gone; not fatal
  }
}
