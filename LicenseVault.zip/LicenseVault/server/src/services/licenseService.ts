import { v4 as uuid } from "uuid";
import { deviceRepo, licenseRepo, type License } from "../db/db.js";
import { generateLicenseKey } from "../utils/crypto.js";
import { ApiError } from "../middleware/errorHandler.js";
import { getProductOrThrow } from "./productService.js";

export function createLicense(params: {
  productId: string;
  maxDevices: number;
  maxUses?: number;
  expiresInDays?: number;
  notes: string;
}) {
  getProductOrThrow(params.productId);

  const id = uuid();
  const key = generateLicenseKey();
  const expiresAt = params.expiresInDays
    ? new Date(Date.now() + params.expiresInDays * 86_400_000).toISOString()
    : null;

  licenseRepo.create({
    id,
    key,
    product_id: params.productId,
    max_devices: params.maxDevices,
    max_uses: params.maxUses ?? null,
    expires_at: expiresAt,
    notes: params.notes,
  });

  return licenseRepo.findById(id)!;
}

export function listLicenses(filters: { productId?: string; status?: string }) {
  return licenseRepo.list(filters);
}

export function getLicenseOrThrow(id: string) {
  const license = licenseRepo.findById(id);
  if (!license) throw new ApiError(404, "License not found.");
  return license;
}

export function revokeLicense(id: string) {
  getLicenseOrThrow(id);
  licenseRepo.revoke(id);
  return licenseRepo.findById(id)!;
}

export function resetDevices(id: string) {
  getLicenseOrThrow(id);
  deviceRepo.resetForLicense(id);
  return deviceRepo.listForLicense(id);
}

export function deleteLicense(id: string) {
  getLicenseOrThrow(id);
  licenseRepo.delete(id);
}

export type LicenseCheckResult =
  | { ok: true; license: License }
  | { ok: false; reason: "not_found" | "revoked" | "expired" | "uses_exhausted" };

/** Pure status check: does NOT touch devices or increment use count. */
export function checkLicenseStatus(key: string): LicenseCheckResult {
  const license = licenseRepo.findByKey(key);
  if (!license) return { ok: false, reason: "not_found" };

  if (license.status === "revoked") return { ok: false, reason: "revoked" };

  if (license.expires_at && new Date(license.expires_at).getTime() < Date.now()) {
    if (license.status !== "expired") licenseRepo.markExpired(license.id);
    return { ok: false, reason: "expired" };
  }

  if (license.max_uses !== null && license.use_count >= license.max_uses) {
    return { ok: false, reason: "uses_exhausted" };
  }

  return { ok: true, license };
}

export type ActivationResult =
  | { ok: true; license: License }
  | { ok: false; reason: "not_found" | "revoked" | "expired" | "uses_exhausted" | "device_limit_reached" };

/**
 * Activates (or re-validates) a device/session against a license.
 *
 * Device IDs are opaque strings generated and persisted by the client
 * application itself — e.g. a UUID written to a local config file. This
 * function never inspects hardware, MAC addresses, disk serials, or any
 * other machine-identifying data; it only counts how many distinct
 * client-supplied IDs are currently associated with the license.
 */
export function activateDevice(key: string, deviceId: string, deviceLabel: string): ActivationResult {
  const status = checkLicenseStatus(key);
  if (!status.ok) return status;

  const { license } = status;
  const existingDevice = deviceRepo.find(license.id, deviceId);

  if (existingDevice) {
    deviceRepo.touch(license.id, deviceId);
  } else {
    const activeDevices = deviceRepo.listForLicense(license.id);
    if (activeDevices.length >= license.max_devices) {
      return { ok: false, reason: "device_limit_reached" };
    }
    deviceRepo.create({ id: uuid(), license_id: license.id, device_id: deviceId, label: deviceLabel });
  }

  licenseRepo.incrementUse(license.id);
  return { ok: true, license };
}
