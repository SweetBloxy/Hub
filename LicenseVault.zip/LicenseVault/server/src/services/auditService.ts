import { v4 as uuid } from "uuid";
import { auditRepo } from "../db/db.js";

export function audit(params: { actor: string; action: string; target?: string; detail?: string; ip?: string }) {
  auditRepo.log({ id: uuid(), ...params });
}
