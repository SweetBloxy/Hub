import Anthropic from "@anthropic-ai/sdk";
import { config } from "../config.js";
import { ApiError } from "../middleware/errorHandler.js";

/**
 * Claude-assisted source cleanup.
 *
 * Scope, deliberately: this is a code-quality pass (consistent formatting,
 * dead-comment/whitespace removal, safe minification), not an
 * anti-analysis or anti-reverse-engineering transform. The system prompt
 * below explicitly forbids behavior changes, invented APIs/dependencies,
 * and structural obfuscation, and instructs the model to leave the code
 * easy to read where that doesn't conflict with minification.
 *
 * The Anthropic API key (config.anthropicApiKey) is only ever read on the
 * server. The dashboard calls `/v1/admin/products/:id/cleanup` on this
 * API; it never calls Anthropic directly and never sees the key.
 */

const SYSTEM_PROMPT = `You clean up source code for a software publisher.

Rules, all mandatory:
- Preserve the program's runtime behavior exactly. Do not change what the code does.
- Do not invent, add, or remove dependencies, imports, or library/API calls that were not already present.
- Do not rename public/exported identifiers (anything another file or caller could reference).
- You may: reformat consistently, remove dead comments and stray whitespace, rename clearly-local/private variables for consistency, and apply safe minification (collapsing whitespace, shortening local-only names) if asked.
- This is NOT an obfuscation request. Do not restructure control flow, do not encode or encrypt string literals, and do not add anti-debugging or anti-analysis logic of any kind.
- If you cannot clean up the code without risking a behavior change, return the original code unchanged and explain why in a trailing comment.
- Output only the resulting source code, nothing else — no markdown fences, no commentary outside code comments.`;

export interface CleanupOptions {
  minify?: boolean;
  language?: string; // free-text hint, e.g. "TypeScript", "Python", "Lua"
}

export async function cleanupSource(source: string, opts: CleanupOptions = {}): Promise<string> {
  if (!config.anthropicApiKey) {
    throw new ApiError(503, "Claude cleanup is not configured (missing ANTHROPIC_API_KEY).");
  }
  if (Buffer.byteLength(source, "utf-8") > config.cleanupMaxSourceBytes) {
    throw new ApiError(413, "Source file is too large for the cleanup pass.");
  }
  if (source.trim().length === 0) {
    throw new ApiError(400, "Source file is empty.");
  }

  const client = new Anthropic({ apiKey: config.anthropicApiKey });

  const instructions = [
    opts.language ? `Language: ${opts.language}.` : "",
    opts.minify ? "Also apply safe minification (collapse whitespace, shorten local-only names)." : "Keep it readable; just clean up formatting and comments.",
  ]
    .filter(Boolean)
    .join(" ");

  const response = await client.messages.create({
    model: config.claudeModel,
    max_tokens: 8192,
    system: SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: `${instructions}\n\nSource:\n\n${source}`,
      },
    ],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new ApiError(502, "Claude did not return a usable response.");
  }

  const cleaned = textBlock.text.trim();
  if (cleaned.length === 0) {
    throw new ApiError(502, "Claude returned an empty result; keeping the original source.");
  }

  return cleaned;
}
