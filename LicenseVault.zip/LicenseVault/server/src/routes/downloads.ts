import { Router } from "express";
import fs from "node:fs";
import { activateSchema } from "../utils/validation.js";
import { activateDevice } from "../services/licenseService.js";
import { latestVersionOrThrow } from "../services/productService.js";
import { productVersionRepo } from "../db/db.js";
import { signDownloadToken, verifyDownloadToken } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";
import { audit } from "../services/auditService.js";
import { config } from "../config.js";
import { ApiError } from "../middleware/errorHandler.js";

export const downloadsRouter = Router();

const activateLimiter = rateLimit({
  windowMs: 60_000,
  max: config.activateRateLimitMaxRequests,
  bucket: "activate",
});

/**
 * POST /v1/activate
 *
 * Public endpoint (no admin token). Validates a license key, enforces
 * expiration/revocation/use-limit/device-limit checks, and — on success —
 * issues a short-lived, single-purpose download token. It never returns
 * the file itself or any admin data.
 */
downloadsRouter.post("/activate", activateLimiter, (req, res) => {
  const { key, deviceId, deviceLabel } = activateSchema.parse(req.body);

  const result = activateDevice(key, deviceId, deviceLabel);

  if (!result.ok) {
    audit({ actor: "anonymous", action: "license.activate_failed", detail: result.reason, ip: req.ip });
    const messages: Record<string, string> = {
      not_found: "License key not recognized.",
      revoked: "This license has been revoked.",
      expired: "This license has expired.",
      uses_exhausted: "This license has reached its maximum number of uses.",
      device_limit_reached: "This license is already active on its maximum number of devices.",
    };
    return res.status(403).json({ error: messages[result.reason] ?? "License is not valid." });
  }

  const version = latestVersionOrThrow(result.license.product_id);
  const downloadToken = signDownloadToken({
    licenseId: result.license.id,
    productVersionId: version.id,
    deviceId,
  });

  audit({
    actor: "anonymous",
    action: "license.activate_succeeded",
    target: result.license.id,
    detail: `device=${deviceId}`,
    ip: req.ip,
  });

  res.json({
    downloadToken,
    expiresInSeconds: config.downloadTokenExpiresInSeconds,
    version: version.version,
    filename: version.filename,
    sha256: version.sha256,
  });
});

/**
 * GET /v1/download?token=...
 *
 * Public endpoint, but only usable with a valid, non-expired download
 * token minted by /v1/activate above. Streams the actual file — this is
 * a normal authenticated file download, not a loadstring/eval loader.
 */
downloadsRouter.get("/download", (req, res) => {
  const token = String(req.query.token ?? "");
  if (!token) throw new ApiError(400, "Missing token.");

  const payload = verifyDownloadToken(token);
  if (!payload) {
    audit({ actor: "anonymous", action: "download.invalid_token", ip: req.ip });
    throw new ApiError(401, "Invalid or expired download token.");
  }

  const version = productVersionRepo.findById(payload.productVersionId);
  if (!version || !fs.existsSync(version.storage_path)) {
    throw new ApiError(404, "The requested file is no longer available.");
  }

  audit({
    actor: "anonymous",
    action: "download.served",
    target: payload.licenseId,
    detail: `version=${version.version} device=${payload.deviceId}`,
    ip: req.ip,
  });

  res.download(version.storage_path, version.filename);
});
