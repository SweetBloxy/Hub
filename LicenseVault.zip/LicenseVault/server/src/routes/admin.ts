import { Router } from "express";
import { requireAdmin } from "../middleware/auth.js";
import { auditRepo, licenseRepo, productRepo } from "../db/db.js";

export const adminRouter = Router();
adminRouter.use(requireAdmin);

adminRouter.get("/audit-logs", (req, res) => {
  const limit = Math.min(Number(req.query.limit ?? 200), 1000);
  res.json(auditRepo.list(limit));
});

/** Lightweight counts for the dashboard's status panel. */
adminRouter.get("/stats", (_req, res) => {
  const products = productRepo.list();
  const licenses = licenseRepo.list();
  res.json({
    productCount: products.length,
    licenseCount: licenses.length,
    activeLicenseCount: licenses.filter((l) => l.status === "active").length,
    revokedLicenseCount: licenses.filter((l) => l.status === "revoked").length,
    expiredLicenseCount: licenses.filter((l) => l.status === "expired").length,
  });
});
