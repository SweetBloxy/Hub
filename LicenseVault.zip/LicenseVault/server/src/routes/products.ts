import { Router } from "express";
import multer from "multer";
import { requireAdmin } from "../middleware/auth.js";
import { createProductSchema, updateProductSchema } from "../utils/validation.js";
import {
  addProductVersion,
  createProduct,
  deleteProduct,
  getProductOrThrow,
  listProducts,
  listVersions,
  updateProduct,
} from "../services/productService.js";
import { cleanupSource } from "../services/claudeCleanup.js";
import { audit } from "../services/auditService.js";
import { config } from "../config.js";
import { ApiError } from "../middleware/errorHandler.js";

export const productsRouter = Router();
productsRouter.use(requireAdmin);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadBytes },
});

productsRouter.get("/", (_req, res) => {
  res.json(listProducts());
});

productsRouter.post("/", (req, res) => {
  const body = createProductSchema.parse(req.body);
  const product = createProduct(body.name, body.description);
  audit({ actor: req.admin!.username, action: "product.create", target: product.id, ip: req.ip });
  res.status(201).json(product);
});

productsRouter.get("/:id", (req, res) => {
  res.json(getProductOrThrow(req.params.id));
});

productsRouter.patch("/:id", (req, res) => {
  const body = updateProductSchema.parse(req.body);
  const updated = updateProduct(req.params.id, body);
  audit({ actor: req.admin!.username, action: "product.update", target: req.params.id, ip: req.ip });
  res.json(updated);
});

productsRouter.delete("/:id", (req, res) => {
  deleteProduct(req.params.id);
  audit({ actor: req.admin!.username, action: "product.delete", target: req.params.id, ip: req.ip });
  res.status(204).send();
});

productsRouter.get("/:id/versions", (req, res) => {
  res.json(listVersions(req.params.id));
});

productsRouter.post("/:id/versions", upload.single("file"), (req, res) => {
  if (!req.file) throw new ApiError(400, "Missing file upload (field name 'file').");
  const version = String(req.body.version ?? "").trim();
  if (!version) throw new ApiError(400, "Missing 'version' field.");

  const created = addProductVersion(req.params.id, version, req.file.originalname, req.file.buffer);
  audit({
    actor: req.admin!.username,
    action: "product.version_upload",
    target: req.params.id,
    detail: `version=${version} sha256=${created.sha256}`,
    ip: req.ip,
  });
  res.status(201).json(created);
});

/**
 * Claude-assisted cleanup. Accepts raw source as text (not multipart),
 * returns the cleaned source in the response body — it does not publish
 * a version automatically. Admin reviews and uploads the result via the
 * versions endpoint above if they're happy with it. This keeps a human
 * in the loop between "Claude touched this" and "this is what ships".
 */
productsRouter.post("/:id/cleanup", async (req, res) => {
  getProductOrThrow(req.params.id);
  const source = String(req.body?.source ?? "");
  const minify = Boolean(req.body?.minify);
  const language = req.body?.language ? String(req.body.language) : undefined;

  const cleaned = await cleanupSource(source, { minify, language });
  audit({
    actor: req.admin!.username,
    action: "product.cleanup",
    target: req.params.id,
    detail: `minify=${minify} language=${language ?? "unspecified"}`,
    ip: req.ip,
  });
  res.json({ cleaned });
});
