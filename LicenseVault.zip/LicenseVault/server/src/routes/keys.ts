import { Router } from "express";
import { requireAdmin } from "../middleware/auth.js";
import { createLicenseSchema } from "../utils/validation.js";
import {
  createLicense,
  deleteLicense,
  getLicenseOrThrow,
  listLicenses,
  resetDevices,
  revokeLicense,
} from "../services/licenseService.js";
import { deviceRepo } from "../db/db.js";
import { audit } from "../services/auditService.js";

export const licensesRouter = Router();
licensesRouter.use(requireAdmin);

licensesRouter.get("/", (req, res) => {
  const { productId, status } = req.query;
  res.json(
    listLicenses({
      productId: typeof productId === "string" ? productId : undefined,
      status: typeof status === "string" ? status : undefined,
    })
  );
});

licensesRouter.post("/", (req, res) => {
  const body = createLicenseSchema.parse(req.body);
  const license = createLicense(body);
  audit({ actor: req.admin!.username, action: "license.create", target: license.id, ip: req.ip });
  res.status(201).json(license);
});

licensesRouter.get("/:id", (req, res) => {
  const license = getLicenseOrThrow(req.params.id);
  res.json({ ...license, devices: deviceRepo.listForLicense(license.id) });
});

licensesRouter.post("/:id/revoke", (req, res) => {
  const license = revokeLicense(req.params.id);
  audit({ actor: req.admin!.username, action: "license.revoke", target: req.params.id, ip: req.ip });
  res.json(license);
});

licensesRouter.post("/:id/reset-devices", (req, res) => {
  const devices = resetDevices(req.params.id);
  audit({ actor: req.admin!.username, action: "license.reset_devices", target: req.params.id, ip: req.ip });
  res.json({ devices });
});

licensesRouter.delete("/:id", (req, res) => {
  deleteLicense(req.params.id);
  audit({ actor: req.admin!.username, action: "license.delete", target: req.params.id, ip: req.ip });
  res.status(204).send();
});
