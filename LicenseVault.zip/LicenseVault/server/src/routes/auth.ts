import { Router } from "express";
import bcrypt from "bcryptjs";
import { adminRepo } from "../db/db.js";
import { signAdminToken } from "../middleware/auth.js";
import { loginSchema } from "../utils/validation.js";
import { audit } from "../services/auditService.js";
import { rateLimit } from "../middleware/rateLimit.js";

export const authRouter = Router();

// Tighter limit on login to slow down credential stuffing / brute force.
const loginLimiter = rateLimit({ windowMs: 60_000, max: 10, bucket: "login" });

authRouter.post("/login", loginLimiter, (req, res) => {
  const { username, password } = loginSchema.parse(req.body);

  const user = adminRepo.findByUsername(username);
  // Always run bcrypt.compareSync even on a missing user, against a dummy
  // hash, so response timing doesn't reveal whether the username exists.
  const dummyHash = "$2a$12$CwTycUXWue0Thq9StjUM0uJ8w2L7rz2hz/KJ3dBpKZr4J4e4O9oZS";
  const matches = bcrypt.compareSync(password, user?.password_hash ?? dummyHash);

  if (!user || !matches) {
    audit({ actor: username, action: "auth.login_failed", ip: req.ip });
    return res.status(401).json({ error: "Invalid username or password." });
  }

  const token = signAdminToken({ sub: user.id, username: user.username });
  audit({ actor: user.username, action: "auth.login_succeeded", ip: req.ip });
  res.json({ token });
});
