import "dotenv/config";
import path from "node:path";

function requireEnv(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return v;
}

export const config = {
  port: Number(process.env.PORT ?? 4000),
  nodeEnv: process.env.NODE_ENV ?? "development",
  trustProxy: process.env.TRUST_PROXY === "true",

  databasePath: path.resolve(process.cwd(), process.env.DATABASE_PATH ?? "./data/licensevault.sqlite"),

  jwtSecret: requireEnv("JWT_SECRET", "dev-only-insecure-secret-change-me"),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "12h",
  downloadTokenExpiresInSeconds: Number(process.env.DOWNLOAD_TOKEN_EXPIRES_IN_SECONDS ?? 300),

  adminUsername: process.env.ADMIN_USERNAME ?? "admin",
  adminPassword: process.env.ADMIN_PASSWORD ?? "change-me",

  rateLimitWindowMs: Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60_000),
  rateLimitMaxRequests: Number(process.env.RATE_LIMIT_MAX_REQUESTS ?? 60),
  activateRateLimitMaxRequests: Number(process.env.ACTIVATE_RATE_LIMIT_MAX_REQUESTS ?? 10),

  productStorageDir: path.resolve(process.cwd(), process.env.PRODUCT_STORAGE_DIR ?? "../storage/products"),
  maxUploadBytes: Number(process.env.MAX_UPLOAD_BYTES ?? 100 * 1024 * 1024),

  anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? "",
  claudeModel: process.env.CLAUDE_MODEL ?? "claude-sonnet-4-6",
  cleanupMaxSourceBytes: Number(process.env.CLEANUP_MAX_SOURCE_BYTES ?? 2_000_000),
};
