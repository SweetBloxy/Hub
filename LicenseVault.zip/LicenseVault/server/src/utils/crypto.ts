import crypto from "node:crypto";

const KEY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I to avoid transcription errors
const KEY_PREFIX = "LV";
const KEY_GROUPS = 4;
const KEY_GROUP_LEN = 6;

/** Generates a license key like LV-AB12CD-EF34GH-IJ56KL-MN78PQ using a CSPRNG. */
export function generateLicenseKey(): string {
  const groups: string[] = [];
  for (let g = 0; g < KEY_GROUPS; g++) {
    let group = "";
    const bytes = crypto.randomBytes(KEY_GROUP_LEN);
    for (let i = 0; i < KEY_GROUP_LEN; i++) {
      group += KEY_ALPHABET[bytes[i] % KEY_ALPHABET.length];
    }
    groups.push(group);
  }
  return `${KEY_PREFIX}-${groups.join("-")}`;
}

export function sha256Hex(data: Buffer | string): string {
  return crypto.createHash("sha256").update(data).digest("hex");
}

/** Constant-time string comparison, used for license key lookups-adjacent checks. */
export function timingSafeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
