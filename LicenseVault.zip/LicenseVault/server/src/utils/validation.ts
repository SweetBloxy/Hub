import { z } from "zod";

export const loginSchema = z.object({
  username: z.string().min(1).max(100),
  password: z.string().min(1).max(200),
});

export const createProductSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(2000).optional().default(""),
});

export const updateProductSchema = z.object({
  name: z.string().min(1).max(200).optional(),
  description: z.string().max(2000).optional(),
  enabled: z.boolean().optional(),
});

export const createLicenseSchema = z.object({
  productId: z.string().min(1),
  maxDevices: z.number().int().min(1).max(1000).optional().default(1),
  maxUses: z.number().int().min(1).optional(),
  expiresInDays: z.number().int().min(1).max(3650).optional(),
  notes: z.string().max(1000).optional().default(""),
});

export const activateSchema = z.object({
  key: z.string().min(1).max(64),
  deviceId: z.string().min(1).max(200),
  deviceLabel: z.string().max(200).optional().default(""),
});

export const KEY_FORMAT = /^LV(-[A-Z0-9]{6}){4}$/;
