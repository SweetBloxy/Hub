/**
 * Data layer.
 *
 * This file is the only place that talks SQL directly. Routes and services
 * call the exported functions below, not better-sqlite3 directly. That
 * boundary is deliberate: to move from SQLite to PostgreSQL later, you
 * reimplement this one file (and schema.sql) against `pg` with the same
 * function signatures — nothing in routes/ or services/ needs to change.
 */
import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";

fs.mkdirSync(path.dirname(config.databasePath), { recursive: true });

export const db = new Database(config.databasePath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

export function applySchema() {
  const schemaPath = path.resolve(import.meta.dirname, "schema.sql");
  const schema = fs.readFileSync(schemaPath, "utf-8");
  db.exec(schema);
}

// ---- Types -----------------------------------------------------------

export interface AdminUser {
  id: string;
  username: string;
  password_hash: string;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  enabled: number;
  created_at: string;
  updated_at: string;
}

export interface ProductVersion {
  id: string;
  product_id: string;
  version: string;
  filename: string;
  storage_path: string;
  sha256: string;
  size_bytes: number;
  is_latest: number;
  created_at: string;
}

export interface License {
  id: string;
  key: string;
  product_id: string;
  status: "active" | "revoked" | "expired";
  max_devices: number;
  max_uses: number | null;
  use_count: number;
  expires_at: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
  revoked_at: string | null;
}

export interface LicenseDevice {
  id: string;
  license_id: string;
  device_id: string;
  label: string;
  first_seen: string;
  last_seen: string;
}

// ---- Admin users -------------------------------------------------------

export const adminRepo = {
  count(): number {
    return (db.prepare("SELECT COUNT(*) as c FROM admin_users").get() as { c: number }).c;
  },
  create(u: Omit<AdminUser, "created_at">) {
    db.prepare(
      "INSERT INTO admin_users (id, username, password_hash) VALUES (?, ?, ?)"
    ).run(u.id, u.username, u.password_hash);
  },
  findByUsername(username: string): AdminUser | undefined {
    return db.prepare("SELECT * FROM admin_users WHERE username = ?").get(username) as
      | AdminUser
      | undefined;
  },
};

// ---- Products ------------------------------------------------------------

export const productRepo = {
  create(p: Pick<Product, "id" | "name" | "description">) {
    db.prepare(
      "INSERT INTO products (id, name, description) VALUES (?, ?, ?)"
    ).run(p.id, p.name, p.description);
  },
  list(): Product[] {
    return db.prepare("SELECT * FROM products ORDER BY created_at DESC").all() as Product[];
  },
  findById(id: string): Product | undefined {
    return db.prepare("SELECT * FROM products WHERE id = ?").get(id) as Product | undefined;
  },
  update(id: string, fields: Partial<Pick<Product, "name" | "description" | "enabled">>) {
    const current = productRepo.findById(id);
    if (!current) return undefined;
    const next = { ...current, ...fields };
    db.prepare(
      "UPDATE products SET name = ?, description = ?, enabled = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(next.name, next.description, next.enabled, id);
    return productRepo.findById(id);
  },
  delete(id: string) {
    db.prepare("DELETE FROM products WHERE id = ?").run(id);
  },
};

export const productVersionRepo = {
  create(v: Omit<ProductVersion, "created_at">) {
    const tx = db.transaction(() => {
      db.prepare("UPDATE product_versions SET is_latest = 0 WHERE product_id = ?").run(
        v.product_id
      );
      db.prepare(
        `INSERT INTO product_versions
         (id, product_id, version, filename, storage_path, sha256, size_bytes, is_latest)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
      ).run(v.id, v.product_id, v.version, v.filename, v.storage_path, v.sha256, v.size_bytes);
    });
    tx();
  },
  listForProduct(productId: string): ProductVersion[] {
    return db
      .prepare("SELECT * FROM product_versions WHERE product_id = ? ORDER BY created_at DESC")
      .all(productId) as ProductVersion[];
  },
  latestForProduct(productId: string): ProductVersion | undefined {
    return db
      .prepare("SELECT * FROM product_versions WHERE product_id = ? AND is_latest = 1")
      .get(productId) as ProductVersion | undefined;
  },
  findById(id: string): ProductVersion | undefined {
    return db.prepare("SELECT * FROM product_versions WHERE id = ?").get(id) as
      | ProductVersion
      | undefined;
  },
};

// ---- Licenses --------------------------------------------------------

export const licenseRepo = {
  create(l: Omit<License, "status" | "use_count" | "created_at" | "updated_at" | "revoked_at">) {
    db.prepare(
      `INSERT INTO licenses
       (id, key, product_id, max_devices, max_uses, expires_at, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(l.id, l.key, l.product_id, l.max_devices, l.max_uses, l.expires_at, l.notes);
  },
  list(filters: { productId?: string; status?: string } = {}): License[] {
    let q = "SELECT * FROM licenses WHERE 1=1";
    const params: unknown[] = [];
    if (filters.productId) {
      q += " AND product_id = ?";
      params.push(filters.productId);
    }
    if (filters.status) {
      q += " AND status = ?";
      params.push(filters.status);
    }
    q += " ORDER BY created_at DESC";
    return db.prepare(q).all(...params) as License[];
  },
  findById(id: string): License | undefined {
    return db.prepare("SELECT * FROM licenses WHERE id = ?").get(id) as License | undefined;
  },
  findByKey(key: string): License | undefined {
    return db.prepare("SELECT * FROM licenses WHERE key = ?").get(key) as License | undefined;
  },
  revoke(id: string) {
    db.prepare(
      "UPDATE licenses SET status = 'revoked', revoked_at = datetime('now'), updated_at = datetime('now') WHERE id = ?"
    ).run(id);
  },
  markExpired(id: string) {
    db.prepare(
      "UPDATE licenses SET status = 'expired', updated_at = datetime('now') WHERE id = ?"
    ).run(id);
  },
  incrementUse(id: string) {
    db.prepare(
      "UPDATE licenses SET use_count = use_count + 1, updated_at = datetime('now') WHERE id = ?"
    ).run(id);
  },
  delete(id: string) {
    db.prepare("DELETE FROM licenses WHERE id = ?").run(id);
  },
};

export const deviceRepo = {
  listForLicense(licenseId: string): LicenseDevice[] {
    return db
      .prepare("SELECT * FROM license_devices WHERE license_id = ? ORDER BY first_seen ASC")
      .all(licenseId) as LicenseDevice[];
  },
  find(licenseId: string, deviceId: string): LicenseDevice | undefined {
    return db
      .prepare("SELECT * FROM license_devices WHERE license_id = ? AND device_id = ?")
      .get(licenseId, deviceId) as LicenseDevice | undefined;
  },
  touch(licenseId: string, deviceId: string) {
    db.prepare(
      "UPDATE license_devices SET last_seen = datetime('now') WHERE license_id = ? AND device_id = ?"
    ).run(licenseId, deviceId);
  },
  create(d: Pick<LicenseDevice, "id" | "license_id" | "device_id" | "label">) {
    db.prepare(
      "INSERT INTO license_devices (id, license_id, device_id, label) VALUES (?, ?, ?, ?)"
    ).run(d.id, d.license_id, d.device_id, d.label);
  },
  resetForLicense(licenseId: string) {
    db.prepare("DELETE FROM license_devices WHERE license_id = ?").run(licenseId);
  },
};

// ---- Audit log ---------------------------------------------------------

export const auditRepo = {
  log(entry: { id: string; actor: string; action: string; target?: string; detail?: string; ip?: string }) {
    db.prepare(
      "INSERT INTO audit_logs (id, actor, action, target, detail, ip) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(entry.id, entry.actor, entry.action, entry.target ?? "", entry.detail ?? "", entry.ip ?? "");
  },
  list(limit = 200) {
    return db.prepare("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?").all(limit);
  },
};
