import bcrypt from "bcryptjs";
import { v4 as uuid } from "uuid";
import { applySchema, adminRepo } from "./db.js";
import { config } from "../config.js";

function main() {
  applySchema();
  console.log("Schema applied.");

  if (adminRepo.count() === 0) {
    const passwordHash = bcrypt.hashSync(config.adminPassword, 12);
    adminRepo.create({ id: uuid(), username: config.adminUsername, password_hash: passwordHash });
    console.log(
      `Created bootstrap admin user "${config.adminUsername}". ` +
        `Change ADMIN_PASSWORD in .env (and this account's password) before deploying.`
    );
  } else {
    console.log("Admin user(s) already exist; skipping bootstrap.");
  }
}

main();
