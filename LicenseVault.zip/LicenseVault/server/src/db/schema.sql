-- LicenseVault schema.
-- Written in portable-ish SQL; sqlite-specific bits are noted. When moving
-- to PostgreSQL, swap TEXT PRIMARY KEY ids for the equivalent (uuid or
-- bigserial), and AUTOINCREMENT semantics are not needed since ids are
-- generated application-side (uuid v4).

CREATE TABLE IF NOT EXISTS admin_users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  enabled     INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS product_versions (
  id            TEXT PRIMARY KEY,
  product_id    TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  version       TEXT NOT NULL,
  filename      TEXT NOT NULL,
  storage_path  TEXT NOT NULL,
  sha256        TEXT NOT NULL,
  size_bytes    INTEGER NOT NULL,
  is_latest     INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(product_id, version)
);

CREATE INDEX IF NOT EXISTS idx_product_versions_product
  ON product_versions(product_id);

CREATE TABLE IF NOT EXISTS licenses (
  id           TEXT PRIMARY KEY,
  key          TEXT NOT NULL UNIQUE,
  product_id   TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  status       TEXT NOT NULL DEFAULT 'active', -- active | revoked | expired
  max_devices  INTEGER NOT NULL DEFAULT 1,
  max_uses     INTEGER,                        -- NULL = unlimited
  use_count    INTEGER NOT NULL DEFAULT 0,
  expires_at   TEXT,                           -- NULL = never
  notes        TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
  revoked_at   TEXT
);

CREATE INDEX IF NOT EXISTS idx_licenses_product ON licenses(product_id);
CREATE INDEX IF NOT EXISTS idx_licenses_status ON licenses(status);

-- Self-reported device/session slots. deviceId is generated and stored by
-- the client application itself (e.g. a UUID persisted locally) — this is
-- a session cap, not a hardware fingerprint, and deliberately does not
-- read any hardware identifiers.
CREATE TABLE IF NOT EXISTS license_devices (
  id          TEXT PRIMARY KEY,
  license_id  TEXT NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
  device_id   TEXT NOT NULL,
  label       TEXT NOT NULL DEFAULT '',
  first_seen  TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(license_id, device_id)
);

CREATE INDEX IF NOT EXISTS idx_license_devices_license
  ON license_devices(license_id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id         TEXT PRIMARY KEY,
  actor      TEXT NOT NULL,   -- admin username, "system", or "anonymous"
  action     TEXT NOT NULL,   -- e.g. license.create, license.activate
  target     TEXT NOT NULL DEFAULT '',
  detail     TEXT NOT NULL DEFAULT '',
  ip         TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at
  ON audit_logs(created_at);
