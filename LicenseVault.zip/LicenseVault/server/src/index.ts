import express from "express";
import cors from "cors";
import helmet from "helmet";
import { config } from "./config.js";
import { applySchema, db } from "./db/db.js";
import { authRouter } from "./routes/auth.js";
import { productsRouter } from "./routes/products.js";
import { licensesRouter } from "./routes/keys.js";
import { downloadsRouter } from "./routes/downloads.js";
import { adminRouter } from "./routes/admin.js";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler.js";
import { rateLimit } from "./middleware/rateLimit.js";

// Make sure the schema exists even if someone forgets `npm run migrate`
// (idempotent: CREATE TABLE IF NOT EXISTS).
applySchema();

const app = express();

if (config.trustProxy) app.set("trust proxy", 1);

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// A general-purpose limiter on everything, with tighter limiters layered
// on top for sensitive endpoints (login, activation) inside their routers.
app.use(
  rateLimit({
    windowMs: config.rateLimitWindowMs,
    max: config.rateLimitMaxRequests,
    bucket: "global",
  })
);

app.get("/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

app.use("/v1/auth", authRouter);
app.use("/v1/admin/products", productsRouter);
app.use("/v1/admin/licenses", licensesRouter);
app.use("/v1/admin", adminRouter);
app.use("/v1", downloadsRouter); // /v1/activate, /v1/download

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(config.port, () => {
  console.log(`LicenseVault API listening on port ${config.port} (${config.nodeEnv})`);
});

process.on("SIGTERM", () => {
  db.close();
  process.exit(0);
});
