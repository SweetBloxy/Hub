import type { NextFunction, Request, Response } from "express";

/**
 * Minimal in-memory fixed-window rate limiter, keyed by IP + a bucket name.
 *
 * This is process-local by design, which is fine for a single instance.
 * If you scale to multiple instances behind a load balancer, swap the
 * `hits` Map below for a shared store (e.g. Redis INCR + EXPIRE) behind
 * the same `check()` signature — nothing else needs to change.
 */
interface Bucket {
  count: number;
  resetAt: number;
}

const hits = new Map<string, Bucket>();

// periodic cleanup so the map doesn't grow unbounded
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of hits) {
    if (bucket.resetAt < now) hits.delete(key);
  }
}, 60_000).unref();

function check(key: string, windowMs: number, max: number): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const existing = hits.get(key);
  if (!existing || existing.resetAt < now) {
    hits.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: max - 1 };
  }
  existing.count += 1;
  const allowed = existing.count <= max;
  return { allowed, remaining: Math.max(0, max - existing.count) };
}

export function rateLimit(opts: { windowMs: number; max: number; bucket: string }) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${opts.bucket}:${req.ip}`;
    const result = check(key, opts.windowMs, opts.max);
    res.setHeader("X-RateLimit-Limit", String(opts.max));
    res.setHeader("X-RateLimit-Remaining", String(result.remaining));
    if (!result.allowed) {
      return res.status(429).json({ error: "Too many requests. Please slow down." });
    }
    next();
  };
}
