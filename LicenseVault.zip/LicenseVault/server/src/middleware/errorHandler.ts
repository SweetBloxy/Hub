import type { NextFunction, Request, Response } from "express";
import { ZodError } from "zod";
import { config } from "../config.js";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

/**
 * Centralized error handler. Never leaks stack traces, internal file
 * paths, or raw driver errors to the client — those go to the server log
 * only. The client gets a safe, generic message plus a request-safe
 * detail where we've deliberately chosen one.
 */
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: "Invalid request.", details: err.issues.map((i) => i.message) });
  }
  if (err instanceof ApiError) {
    return res.status(err.status).json({ error: err.message });
  }

  console.error("Unhandled error:", err);
  const message =
    config.nodeEnv === "development" && err instanceof Error ? err.message : "Internal server error.";
  return res.status(500).json({ error: message });
}

export function notFoundHandler(_req: Request, res: Response) {
  res.status(404).json({ error: "Not found." });
}
