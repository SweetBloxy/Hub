import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { config } from "../config.js";

export interface AdminJwtPayload {
  sub: string; // admin user id
  username: string;
  type: "admin";
}

export interface DownloadJwtPayload {
  type: "download";
  licenseId: string;
  productVersionId: string;
  deviceId: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      admin?: AdminJwtPayload;
    }
  }
}

export function signAdminToken(payload: Omit<AdminJwtPayload, "type">): string {
  return jwt.sign({ ...payload, type: "admin" }, config.jwtSecret, {
    expiresIn: config.jwtExpiresIn,
  } as jwt.SignOptions);
}

export function signDownloadToken(payload: Omit<DownloadJwtPayload, "type">): string {
  return jwt.sign({ ...payload, type: "download" }, config.jwtSecret, {
    expiresIn: config.downloadTokenExpiresInSeconds,
  });
}

/** Requires a valid admin bearer token. Never trusts anything client-supplied beyond the signed token. */
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or malformed Authorization header." });
  }
  const token = header.slice("Bearer ".length);
  try {
    const decoded = jwt.verify(token, config.jwtSecret) as AdminJwtPayload;
    if (decoded.type !== "admin") {
      return res.status(401).json({ error: "Invalid token type." });
    }
    req.admin = decoded;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token." });
  }
}

export function verifyDownloadToken(token: string): DownloadJwtPayload | null {
  try {
    const decoded = jwt.verify(token, config.jwtSecret) as DownloadJwtPayload;
    if (decoded.type !== "download") return null;
    return decoded;
  } catch {
    return null;
  }
}
