import { describe, it, expect, beforeAll, beforeEach } from "vitest";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

// Point the app at a throwaway sqlite file before importing anything that
// opens the database (config/db read env vars at import time).
const tmpDb = path.join(os.tmpdir(), `licensevault-test-${process.pid}-${Date.now()}.sqlite`);
process.env.DATABASE_PATH = tmpDb;
process.env.JWT_SECRET = "test-secret";
process.env.ADMIN_USERNAME = "admin";
process.env.ADMIN_PASSWORD = "test-password";
process.env.PRODUCT_STORAGE_DIR = path.join(os.tmpdir(), `licensevault-test-storage-${process.pid}`);

const { generateLicenseKey } = await import("../src/utils/crypto.js");
const { KEY_FORMAT } = await import("../src/utils/validation.js");
const { applySchema, db } = await import("../src/db/db.js");
const { createProduct } = await import("../src/services/productService.js");
const {
  createLicense,
  checkLicenseStatus,
  activateDevice,
  revokeLicense,
  resetDevices,
} = await import("../src/services/licenseService.js");

beforeAll(() => {
  applySchema();
});

beforeEach(() => {
  // Wipe all tables between tests for isolation.
  db.exec(
    "DELETE FROM license_devices; DELETE FROM licenses; DELETE FROM product_versions; DELETE FROM products; DELETE FROM admin_users; DELETE FROM audit_logs;"
  );
});

describe("generateLicenseKey", () => {
  it("produces keys matching the documented format", () => {
    for (let i = 0; i < 50; i++) {
      const key = generateLicenseKey();
      expect(key).toMatch(KEY_FORMAT);
    }
  });

  it("does not produce obvious collisions across many generations", () => {
    const keys = new Set<string>();
    for (let i = 0; i < 1000; i++) keys.add(generateLicenseKey());
    expect(keys.size).toBe(1000);
  });
});

describe("license lifecycle", () => {
  function setupProduct() {
    return createProduct("Test Product", "A product for tests");
  }

  it("a freshly created license is valid", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 2, notes: "" });
    const status = checkLicenseStatus(license.key);
    expect(status.ok).toBe(true);
  });

  it("rejects an unknown key", () => {
    const status = checkLicenseStatus("LV-AAAAAA-BBBBBB-CCCCCC-DDDDDD");
    expect(status.ok).toBe(false);
    if (!status.ok) expect(status.reason).toBe("not_found");
  });

  it("rejects a revoked license", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 1, notes: "" });
    revokeLicense(license.id);
    const status = checkLicenseStatus(license.key);
    expect(status.ok).toBe(false);
    if (!status.ok) expect(status.reason).toBe("revoked");
  });

  it("rejects an expired license and marks it expired", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 1, expiresInDays: 1, notes: "" });
    // Force expiry into the past directly via DB for test determinism.
    db.prepare("UPDATE licenses SET expires_at = ? WHERE id = ?").run(
      new Date(Date.now() - 1000).toISOString(),
      license.id
    );
    const status = checkLicenseStatus(license.key);
    expect(status.ok).toBe(false);
    if (!status.ok) expect(status.reason).toBe("expired");
  });

  it("enforces max_uses", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 10, maxUses: 2, notes: "" });
    expect(activateDevice(license.key, "device-1", "").ok).toBe(true);
    expect(activateDevice(license.key, "device-2", "").ok).toBe(true);
    const third = activateDevice(license.key, "device-3", "");
    expect(third.ok).toBe(false);
    if (!third.ok) expect(third.reason).toBe("uses_exhausted");
  });

  it("enforces max_devices independent of max_uses", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 1, notes: "" });
    const first = activateDevice(license.key, "device-a", "laptop");
    expect(first.ok).toBe(true);

    // Re-activating the same device should succeed (it's already counted).
    const again = activateDevice(license.key, "device-a", "laptop");
    expect(again.ok).toBe(true);

    // A second distinct device should be rejected once at the cap.
    const second = activateDevice(license.key, "device-b", "desktop");
    expect(second.ok).toBe(false);
    if (!second.ok) expect(second.reason).toBe("device_limit_reached");
  });

  it("reset-devices frees up device slots", () => {
    const product = setupProduct();
    const license = createLicense({ productId: product.id, maxDevices: 1, notes: "" });
    activateDevice(license.key, "device-a", "");
    expect(activateDevice(license.key, "device-b", "").ok).toBe(false);

    resetDevices(license.id);

    const afterReset = activateDevice(license.key, "device-b", "");
    expect(afterReset.ok).toBe(true);
  });
});
