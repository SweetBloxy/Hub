import { describe, it, expect, beforeAll } from "vitest";
import path from "node:path";
import os from "node:os";
import type { Express } from "express";

// Isolated env/db per test file, set before any app module is imported.
process.env.DATABASE_PATH = path.join(os.tmpdir(), `licensevault-api-test-${process.pid}.sqlite`);
process.env.JWT_SECRET = "test-secret-for-api-tests";
process.env.ADMIN_USERNAME = "admin";
process.env.ADMIN_PASSWORD = "test-password-123";
process.env.PRODUCT_STORAGE_DIR = path.join(os.tmpdir(), `licensevault-api-test-storage-${process.pid}`);

let app: Express;
let adminToken: string;

async function buildTestApp() {
  // Re-implements the minimal wiring from src/index.ts without calling
  // app.listen(), so tests can drive the Express app in-process.
  const express = (await import("express")).default;
  const { applySchema } = await import("../src/db/db.js");
  const { authRouter } = await import("../src/routes/auth.js");
  const { productsRouter } = await import("../src/routes/products.js");
  const { licensesRouter } = await import("../src/routes/keys.js");
  const { downloadsRouter } = await import("../src/routes/downloads.js");
  const { errorHandler, notFoundHandler } = await import("../src/middleware/errorHandler.js");

  applySchema();

  const testApp = express();
  testApp.use(express.json());
  testApp.use("/v1/auth", authRouter);
  testApp.use("/v1/admin/products", productsRouter);
  testApp.use("/v1/admin/licenses", licensesRouter);
  testApp.use("/v1", downloadsRouter);
  testApp.use(notFoundHandler);
  testApp.use(errorHandler);
  return testApp;
}

async function jsonRequest(
  app: Express,
  method: string,
  url: string,
  body?: unknown,
  token?: string
) {
  const { default: request } = await import("supertest");
  let r = request(app)[method.toLowerCase() as "get"](url);
  if (token) r = r.set("Authorization", `Bearer ${token}`);
  if (body !== undefined) r = r.send(body);
  return r;
}

beforeAll(async () => {
  const bcrypt = (await import("bcryptjs")).default;
  const { v4: uuid } = await import("uuid");
  const { adminRepo } = await import("../src/db/db.js");

  app = await buildTestApp();

  const passwordHash = bcrypt.hashSync("test-password-123", 10);
  if (!adminRepo.findByUsername("admin")) {
    adminRepo.create({ id: uuid(), username: "admin", password_hash: passwordHash });
  }

  const loginRes = await jsonRequest(app, "POST", "/v1/auth/login", {
    username: "admin",
    password: "test-password-123",
  });
  adminToken = loginRes.body.token;
});

describe("auth", () => {
  it("rejects bad credentials", async () => {
    const res = await jsonRequest(app, "POST", "/v1/auth/login", {
      username: "admin",
      password: "wrong-password",
    });
    expect(res.status).toBe(401);
  });

  it("logs in with correct credentials", async () => {
    expect(adminToken).toBeTruthy();
  });
});

describe("admin endpoints require auth", () => {
  it("rejects product list without a token", async () => {
    const res = await jsonRequest(app, "GET", "/v1/admin/products");
    expect(res.status).toBe(401);
  });

  it("allows product list with a valid token", async () => {
    const res = await jsonRequest(app, "GET", "/v1/admin/products", undefined, adminToken);
    expect(res.status).toBe(200);
  });
});

describe("license + activation flow", () => {
  it("creates a product and a license, then rejects activation with no published version", async () => {
    const productRes = await jsonRequest(
      app,
      "POST",
      "/v1/admin/products",
      { name: "Flow Test Product", description: "" },
      adminToken
    );
    expect(productRes.status).toBe(201);
    const productId = productRes.body.id;

    const licenseRes = await jsonRequest(
      app,
      "POST",
      "/v1/admin/licenses",
      { productId, maxDevices: 1 },
      adminToken
    );
    expect(licenseRes.status).toBe(201);
    const key = licenseRes.body.key;
    expect(key).toMatch(/^LV(-[A-Z0-9]{6}){4}$/);

    // No version uploaded yet, so activation should fail even though the
    // license itself is valid.
    const activateRes = await jsonRequest(app, "POST", "/v1/activate", {
      key,
      deviceId: "test-device-1",
    });
    expect(activateRes.status).toBe(404);
  });

  it("rejects activation for an unknown key", async () => {
    const res = await jsonRequest(app, "POST", "/v1/activate", {
      key: "LV-ZZZZZZ-ZZZZZZ-ZZZZZZ-ZZZZZZ",
      deviceId: "device-x",
    });
    expect(res.status).toBe(403);
    expect(res.body.error).toMatch(/not recognized/i);
  });
});
