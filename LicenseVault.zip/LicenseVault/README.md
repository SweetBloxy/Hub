# LicenseVault

A self-hosted license-key management and authenticated software-download platform.

LicenseVault lets you:

- Publish versioned product files (binaries, scripts, assets — anything)
- Generate, validate, expire, and revoke license keys
- Cap each license to a number of concurrent devices/sessions (self-reported
  device IDs, **not** hardware fingerprinting)
- Serve downloads only to activated, valid licenses via short-lived signed
  download tokens — there is no "fetch and `eval` this at runtime" loader;
  the client downloads a real file over HTTPS the way any installer or
  package manager does
- Optionally run new/updated source files through a Claude-assisted
  cleanup pass (formatting, dead-comment removal, minification) — this is
  a code-quality step, not an anti-analysis / anti-reverse-engineering
  step, and it is documented as such
- Keep an audit log of admin and licensing actions
- Rate-limit and authenticate all admin and activation endpoints

## What this is *not*

LicenseVault does not try to make delivered code impossible to read or
analyze. Anything your license holders run on their own machines, they can
eventually inspect — this project does not pretend otherwise. It focuses on
**access control and distribution**, not obfuscation-as-security.

## Project layout

```
LicenseVault/
├── server/                 # Node.js + TypeScript API
│   ├── src/
│   │   ├── index.ts
│   │   ├── config.ts
│   │   ├── db/              # schema + sqlite/postgres-ready data layer
│   │   ├── middleware/      # auth, rate limiting, error handling
│   │   ├── routes/          # auth, products, licenses, downloads, admin
│   │   ├── services/        # license logic, audit log, Claude cleanup
│   │   └── utils/           # crypto helpers, validation schemas
│   ├── tests/
│   ├── package.json
│   └── .env.example
├── dashboard/               # static admin dashboard (vanilla HTML/JS)
│   └── index.html
├── storage/products/        # uploaded product files live here (gitignored)
└── README.md
```

## Quick start

```bash
cd server
cp .env.example .env
npm install
npm run migrate
npm run dev
```

The API listens on `http://localhost:4000` by default. Open
`dashboard/index.html` in a browser (or serve it with any static file
server) and point it at that URL to log in.

Default admin account is created by the migration using
`ADMIN_USERNAME` / `ADMIN_PASSWORD` from `.env` — change these before
deploying anywhere real.

## Development commands

```bash
npm run dev        # run with tsx, auto-reload
npm run build      # compile TypeScript to dist/
npm start          # run compiled build
npm run migrate    # apply database schema
npm test           # run unit tests
```

## Production deployment notes

- Set `NODE_ENV=production`, a long random `JWT_SECRET`, and a strong
  `ADMIN_PASSWORD` (or better, create additional admin users and disable
  the bootstrap account) before exposing this publicly.
- Put the API behind a reverse proxy (nginx, Caddy, or your platform's
  load balancer) that terminates TLS. The app itself trusts
  `X-Forwarded-For` only when `TRUST_PROXY=true`.
- SQLite is fine for a single instance / low-to-moderate traffic. The data
  layer (`server/src/db/db.ts`) is written as a small repository
  interface specifically so it can be swapped for a PostgreSQL
  implementation (e.g. via `pg`) later without touching route/service
  code — see the comment at the top of that file.
- The in-memory rate limiter (`middleware/rateLimit.ts`) is per-process.
  If you run multiple instances behind a load balancer, replace it with a
  shared store (Redis) using the same interface.
- Back up `data/licensevault.sqlite` and `storage/products/` regularly.
- Never commit `.env` or the sqlite file.

## Example API requests

Log in as admin:

```bash
curl -X POST http://localhost:4000/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"change-me"}'
# => { "token": "eyJ..." }
```

Create a product:

```bash
curl -X POST http://localhost:4000/v1/admin/products \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"name":"MyApp Pro","description":"Desktop app"}'
```

Upload a file as a new version:

```bash
curl -X POST http://localhost:4000/v1/admin/products/$PRODUCT_ID/versions \
  -H "Authorization: Bearer $TOKEN" \
  -F "version=1.0.0" \
  -F "file=@./MyApp-1.0.0.zip"
```

Generate a license key:

```bash
curl -X POST http://localhost:4000/v1/admin/licenses \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"productId":"'$PRODUCT_ID'","maxDevices":2,"expiresInDays":365}'
# => { "key": "LV-AB12CD34EF56GH78IJ12KL34", ... }
```

Activate a license from the client and get a download token:

```bash
curl -X POST http://localhost:4000/v1/activate \
  -H 'Content-Type: application/json' \
  -d '{"key":"LV-AB12CD34EF56GH78IJ12KL34","deviceId":"<client-generated-uuid>"}'
# => { "downloadToken": "eyJ...", "expiresInSeconds": 300, "version": "1.0.0" }
```

Download the file:

```bash
curl -L "http://localhost:4000/v1/download?token=$DOWNLOAD_TOKEN" -o MyApp.zip
```

Revoke a license:

```bash
curl -X POST http://localhost:4000/v1/admin/licenses/$LICENSE_ID/revoke \
  -H "Authorization: Bearer $TOKEN"
```

Reset device/session slots on a license:

```bash
curl -X POST http://localhost:4000/v1/admin/licenses/$LICENSE_ID/reset-devices \
  -H "Authorization: Bearer $TOKEN"
```

## Claude-assisted cleanup

`POST /v1/admin/products/:id/cleanup` sends a submitted source file to
Claude (model set via `CLAUDE_MODEL` in `.env`) with instructions to:

- reformat and remove dead comments/whitespace
- apply safe minification
- **preserve behavior exactly** and never invent APIs or dependencies

It is a code-quality convenience, explicitly scoped away from
anti-analysis transforms, and the Claude API key never leaves the server
(the dashboard never talks to Anthropic directly).
