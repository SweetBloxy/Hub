#!/usr/bin/env node
/**
 * Example client: activates a license and downloads the latest file over
 * a normal authenticated HTTPS request. There is no remote `eval`/
 * `loadstring` step anywhere in this flow — the result is a real file on
 * disk that the user (or their own installer) decides what to do with.
 *
 * The device ID below is generated once and persisted locally by the
 * client app (e.g. in a config file next to the executable). It is an
 * opaque random value the client controls, not a hardware fingerprint.
 *
 * Usage:
 *   VAULT_URL=http://localhost:4000 LICENSE_KEY=LV-XXXX... node client-example.js
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import os from "node:os";

const VAULT_URL = process.env.VAULT_URL || "http://localhost:4000";
const LICENSE_KEY = process.env.LICENSE_KEY;

if (!LICENSE_KEY) {
  console.error("Set LICENSE_KEY to your LV-... license key.");
  process.exit(1);
}

function getOrCreateDeviceId() {
  const configPath = path.join(os.homedir(), ".licensevault-client.json");
  try {
    const existing = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    if (existing.deviceId) return existing.deviceId;
  } catch {
    // no config yet
  }
  const deviceId = crypto.randomUUID();
  fs.writeFileSync(configPath, JSON.stringify({ deviceId }, null, 2));
  return deviceId;
}

async function main() {
  const deviceId = getOrCreateDeviceId();

  const activateRes = await fetch(`${VAULT_URL}/v1/activate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key: LICENSE_KEY, deviceId, deviceLabel: os.hostname() }),
  });

  const activateBody = await activateRes.json();
  if (!activateRes.ok) {
    console.error("Activation failed:", activateBody.error || activateRes.statusText);
    process.exit(1);
  }

  console.log(`Activated. Latest version: ${activateBody.version}`);

  const downloadRes = await fetch(
    `${VAULT_URL}/v1/download?token=${encodeURIComponent(activateBody.downloadToken)}`
  );
  if (!downloadRes.ok) {
    const body = await downloadRes.json().catch(() => ({}));
    console.error("Download failed:", body.error || downloadRes.statusText);
    process.exit(1);
  }

  const outPath = path.join(process.cwd(), activateBody.filename);
  const arrayBuffer = await downloadRes.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  // Verify integrity against the hash the server told us about at
  // activation time, before trusting the file at all.
  const actualHash = crypto.createHash("sha256").update(buffer).digest("hex");
  if (actualHash !== activateBody.sha256) {
    console.error("Downloaded file hash mismatch — refusing to save it.");
    process.exit(1);
  }

  fs.writeFileSync(outPath, buffer);
  console.log(`Saved ${activateBody.filename} to ${outPath} (sha256 verified).`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
